"use client";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { TaskCard } from "./task-card";
import { TaskForm } from "./task-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TaskListSkeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, Search, SlidersHorizontal, CheckCircle2 } from "lucide-react";

type Status = "all" | "todo" | "in_progress" | "done";
type Priority = "all" | "low" | "medium" | "high";

export function TaskList() {
  const [createOpen, setCreateOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<Status>("all");
  const [priority, setPriority] = useState<Priority>("all");

  const { data: tasks, isLoading, isError } = trpc.tasks.list.useQuery({
    status,
    priority,
    search: search || undefined,
  });

  const todoCount = tasks?.filter((t) => t.status === "todo").length ?? 0;
  const inProgressCount = tasks?.filter((t) => t.status === "in_progress").length ?? 0;
  const doneCount = tasks?.filter((t) => t.status === "done").length ?? 0;

  const hasFilters = search || status !== "all" || priority !== "all";

  if (isLoading) return <TaskListSkeleton />;

  return (
    <div className="space-y-6">
      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "To Do", count: todoCount, color: "text-muted-foreground", bg: "bg-muted/50", onClick: () => setStatus(status === "todo" ? "all" : "todo"), active: status === "todo" },
          { label: "In Progress", count: inProgressCount, color: "text-blue-500", bg: "bg-blue-500/10", onClick: () => setStatus(status === "in_progress" ? "all" : "in_progress"), active: status === "in_progress" },
          { label: "Done", count: doneCount, color: "text-emerald-500", bg: "bg-emerald-500/10", onClick: () => setStatus(status === "done" ? "all" : "done"), active: status === "done" },
        ].map(({ label, count, color, bg, onClick, active }) => (
          <button
            key={label}
            onClick={onClick}
            className={`rounded-xl p-3 text-center transition-all duration-150 hover:scale-105 active:scale-95 cursor-pointer ${bg} ${active ? "ring-2 ring-offset-2 ring-offset-background ring-primary" : ""}`}
          >
            <div className={`text-2xl font-bold ${color}`}>{count}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
          </button>
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="flex gap-2">
          <Select value={status} onValueChange={(v) => setStatus(v as Status)}>
            <SelectTrigger className="w-[140px]">
              <SlidersHorizontal className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="todo">To Do</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="done">Done</SelectItem>
            </SelectContent>
          </Select>

          <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="All Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priority</SelectItem>
              <SelectItem value="high">🔴 High</SelectItem>
              <SelectItem value="medium">🟡 Medium</SelectItem>
              <SelectItem value="low">🟢 Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Active filter chips */}
      {hasFilters && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs text-muted-foreground">Filters:</span>
          {status !== "all" && (
            <button
              onClick={() => setStatus("all")}
              className="text-xs rounded-full border px-2.5 py-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
            >
              Status: {status.replace("_", " ")} ✕
            </button>
          )}
          {priority !== "all" && (
            <button
              onClick={() => setPriority("all")}
              className="text-xs rounded-full border px-2.5 py-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
            >
              Priority: {priority} ✕
            </button>
          )}
          {search && (
            <button
              onClick={() => setSearch("")}
              className="text-xs rounded-full border px-2.5 py-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
            >
              Search: "{search}" ✕
            </button>
          )}
          <button
            onClick={() => { setStatus("all"); setPriority("all"); setSearch(""); }}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors ml-1"
          >
            Clear all
          </button>
        </div>
      )}

      {/* Error state */}
      {isError && (
        <div className="text-center py-16 rounded-xl border border-destructive/20 bg-destructive/5">
          <p className="text-destructive font-medium">Failed to load tasks</p>
          <p className="text-sm text-muted-foreground mt-1">Please refresh the page</p>
        </div>
      )}

      {/* Empty state */}
      {!isError && tasks?.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="rounded-full bg-muted p-6 mb-4">
            <CheckCircle2 className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold">
            {hasFilters ? "No matching tasks" : "No tasks yet"}
          </h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-xs">
            {hasFilters
              ? "Try adjusting your filters to see more tasks."
              : "Hit the + button to create your first task!"}
          </p>
          {hasFilters && (
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => { setStatus("all"); setPriority("all"); setSearch(""); }}
            >
              Clear filters
            </Button>
          )}
        </div>
      )}

      {/* Task cards */}
      {!isError && tasks && tasks.length > 0 && (
        <div className="space-y-3">
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}
          <p className="text-center text-xs text-muted-foreground pt-2">
            {tasks.length} task{tasks.length !== 1 ? "s" : ""}
            {hasFilters ? " matching" : " total"}
          </p>
        </div>
      )}

      {/* FAB */}
      <Button
        onClick={() => setCreateOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg hover:shadow-xl hover:scale-110 active:scale-95 transition-all duration-150"
        size="icon"
        title="New task"
      >
        <Plus className="h-6 w-6" />
      </Button>

      <TaskForm open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  );
}
