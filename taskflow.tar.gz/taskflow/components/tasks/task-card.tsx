"use client";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TaskForm } from "./task-form";
import type { Task } from "@/db/schema";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  MoreHorizontal, Pencil, Trash2, CheckCircle2, Clock, Circle, CalendarDays,
} from "lucide-react";
import { format } from "date-fns";

const priorityConfig = {
  low: { label: "Low", variant: "success" as const, dot: "bg-emerald-500" },
  medium: { label: "Medium", variant: "warning" as const, dot: "bg-amber-500" },
  high: { label: "High", variant: "danger" as const, dot: "bg-red-500" },
};

const statusConfig = {
  todo: { label: "To Do", icon: Circle, color: "text-muted-foreground" },
  in_progress: { label: "In Progress", icon: Clock, color: "text-blue-500" },
  done: { label: "Done", icon: CheckCircle2, color: "text-emerald-500" },
};

interface TaskCardProps {
  task: Task;
}

export function TaskCard({ task }: TaskCardProps) {
  const [editOpen, setEditOpen] = useState(false);
  const utils = trpc.useUtils();

  const deleteMutation = trpc.tasks.delete.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });

  const updateStatus = trpc.tasks.update.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
  });

  const p = priorityConfig[task.priority as keyof typeof priorityConfig];
  const s = statusConfig[task.status as keyof typeof statusConfig];
  const StatusIcon = s.icon;

  const isOverdue =
    task.dueDate &&
    task.status !== "done" &&
    new Date(task.dueDate) < new Date();

  const toggleDone = () => {
    updateStatus.mutate({
      id: task.id,
      status: task.status === "done" ? "todo" : "done",
    });
  };

  return (
    <>
      <div
        className={`group relative flex gap-3 rounded-xl border bg-card p-4 shadow-sm transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 ${
          task.status === "done" ? "opacity-60" : ""
        }`}
      >
        {/* Priority bar */}
        <div className={`absolute left-0 top-3 bottom-3 w-1 rounded-full ${p.dot} opacity-70`} />

        {/* Status toggle */}
        <button
          onClick={toggleDone}
          className={`mt-0.5 flex-shrink-0 transition-colors ${s.color} hover:scale-110`}
          disabled={updateStatus.isPending}
        >
          <StatusIcon className="h-5 w-5" />
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3
              className={`font-semibold text-sm leading-snug ${
                task.status === "done" ? "line-through text-muted-foreground" : "text-foreground"
              }`}
            >
              {task.title}
            </h3>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 opacity-0 group-hover:opacity-100 flex-shrink-0"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setEditOpen(true)}>
                  <Pencil className="mr-2 h-4 w-4" /> Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => deleteMutation.mutate({ id: task.id })}
                >
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {task.description && (
            <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
              {task.description}
            </p>
          )}

          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge variant={p.variant}>{p.label}</Badge>

            {task.dueDate && (
              <span
                className={`flex items-center gap-1 text-xs ${
                  isOverdue ? "text-red-500 font-medium" : "text-muted-foreground"
                }`}
              >
                <CalendarDays className="h-3 w-3" />
                {isOverdue ? "Overdue · " : ""}
                {format(new Date(task.dueDate + "T00:00:00"), "MMM d, yyyy")}
              </span>
            )}
          </div>
        </div>
      </div>

      <TaskForm open={editOpen} onClose={() => setEditOpen(false)} task={task} />
    </>
  );
}
