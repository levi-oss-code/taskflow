import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { email, name, image } = await req.json();
    if (!email) return NextResponse.json({ error: "No email" }, { status: 400 });

    const existing = await db.select().from(users).where(eq(users.email, email)).get();
    if (existing) return NextResponse.json({ id: existing.id });

    const id = `user_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    await db.insert(users).values({ id, name, email, image });
    return NextResponse.json({ id });
  } catch (e) {
    console.error("upsert-user error", e);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
