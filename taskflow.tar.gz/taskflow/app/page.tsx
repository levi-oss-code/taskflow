import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Navbar } from "@/components/navbar";
import { TaskList } from "@/components/tasks/task-list";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={session.user} />
      <main className="mx-auto max-w-3xl px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">
            Good {getGreeting()},{" "}
            <span className="text-primary">
              {session.user.name?.split(" ")[0] ?? "there"}
            </span>
            !
          </h1>
          <p className="mt-1 text-muted-foreground">
            Here&apos;s what&apos;s on your plate today.
          </p>
        </div>
        <TaskList />
      </main>
    </div>
  );
}

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}
