import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LoginButton } from "./login-button";
import { CheckSquare } from "lucide-react";

export default async function LoginPage() {
  const session = await auth();
  if (session?.user) redirect("/");

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/30 p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo */}
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <div className="rounded-2xl bg-primary p-4 shadow-lg">
              <CheckSquare className="h-10 w-10 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-4xl font-bold tracking-tight">TaskFlow</h1>
          <p className="text-muted-foreground">
            Your personal task management workspace
          </p>
        </div>

        {/* Card */}
        <div className="rounded-2xl border bg-card p-8 shadow-lg space-y-6">
          <div className="space-y-2 text-center">
            <h2 className="text-2xl font-semibold">Welcome back</h2>
            <p className="text-sm text-muted-foreground">
              Sign in to access your tasks
            </p>
          </div>

          <LoginButton />

          <div className="grid grid-cols-3 gap-4 pt-2">
            {[
              { icon: "⚡", label: "Fast" },
              { icon: "🔒", label: "Secure" },
              { icon: "🌙", label: "Dark mode" },
            ].map(({ icon, label }) => (
              <div key={label} className="text-center space-y-1">
                <div className="text-2xl">{icon}</div>
                <div className="text-xs text-muted-foreground">{label}</div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          Built with Next.js · tRPC · Drizzle ORM
        </p>
      </div>
    </div>
  );
}
