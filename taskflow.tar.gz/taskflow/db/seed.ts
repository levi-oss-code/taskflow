import { createClient } from "@libsql/client";
import path from "path";

const dbPath = process.env.DATABASE_URL ?? `file:${path.join(process.cwd(), "taskflow.db")}`;
const client = createClient({ url: dbPath });

async function seed() {
  console.log("Seeding database...");

  // Create a demo user
  const userId = "user_demo_001";
  await client.execute({
    sql: `INSERT OR IGNORE INTO users (id, name, email, image) VALUES (?, ?, ?, ?)`,
    args: [userId, "Demo User", "demo@example.com", null],
  });

  const tasks = [
    { title: "Set up GitHub OAuth", description: "Create a GitHub OAuth app and configure credentials", status: "done", priority: "high", dueDate: null },
    { title: "Write API tests", description: "Cover all tRPC routes with integration tests", status: "in_progress", priority: "high", dueDate: new Date(Date.now() + 2 * 86400000).toISOString().split("T")[0] },
    { title: "Design dark mode UI", description: "Implement CSS variables and theme toggle", status: "done", priority: "medium", dueDate: null },
    { title: "Deploy to Vercel", description: "Configure environment variables and deploy", status: "todo", priority: "high", dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split("T")[0] },
    { title: "Set up Turso database", description: "Migrate from local SQLite to Turso for production", status: "todo", priority: "medium", dueDate: new Date(Date.now() + 5 * 86400000).toISOString().split("T")[0] },
    { title: "Add task labels/tags", description: "Allow users to categorise tasks with custom labels", status: "todo", priority: "low", dueDate: null },
    { title: "Write user documentation", description: "Create README with setup instructions and architecture overview", status: "todo", priority: "low", dueDate: null },
    { title: "Mobile responsive audit", description: "Test all breakpoints and fix layout issues on small screens", status: "in_progress", priority: "medium", dueDate: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0] },
  ];

  for (const task of tasks) {
    const id = `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    await client.execute({
      sql: `INSERT OR IGNORE INTO tasks (id, title, description, status, priority, due_date, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      args: [id, task.title, task.description, task.status, task.priority, task.dueDate, userId],
    });
    await new Promise((r) => setTimeout(r, 5)); // ensure unique IDs
  }

  console.log(`✅ Seeded ${tasks.length} tasks for demo user`);
  process.exit(0);
}

seed().catch((e) => {
  console.error("Seed failed:", e);
  process.exit(1);
});
