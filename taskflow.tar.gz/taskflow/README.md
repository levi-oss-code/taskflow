# TaskFlow 📋

A full-stack task management app built with **Next.js 16**, **tRPC**, **Drizzle ORM**, and **GitHub OAuth**.

![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)
![Next.js](https://img.shields.io/badge/Next.js-16-black?logo=next.js)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-v4-38bdf8?logo=tailwindcss)
![Tests](https://img.shields.io/badge/tests-12%20passing-brightgreen)

---

## Features

- ✅ Create, edit, delete tasks
- 🏷️ Task priority (low / medium / high) with colour-coded indicators
- 📅 Due dates with overdue detection
- 🔍 Real-time search by title
- 🎛️ Filter by status and priority with clickable stat chips
- 🌙 Dark / light / system theme toggle
- 🔒 GitHub OAuth login — protected routes via middleware
- 📱 Responsive layout (mobile + desktop)
- ⚡ Type-safe end-to-end with tRPC + Zod

---

## Tech Stack

| Layer      | Technology |
|------------|------------|
| Framework  | Next.js 16 (App Router, Turbopack) |
| UI         | Tailwind CSS v4, Radix UI primitives |
| API        | tRPC v11 (React Query) |
| Validation | Zod v3 |
| Database   | LibSQL (SQLite locally · Turso in production) |
| ORM        | Drizzle ORM |
| Auth       | NextAuth.js v5 (GitHub OAuth, JWT strategy) |
| Testing    | Vitest + in-memory LibSQL |
| Deploy     | Vercel |

---

## Quick Start

### 1. Clone and install

```bash
git clone https://github.com/your-username/taskflow.git
cd taskflow
npm install
```

### 2. Create a GitHub OAuth app

Go to [GitHub Developer Settings → OAuth Apps](https://github.com/settings/developers) and create a new app:

| Field | Value |
|-------|-------|
| Homepage URL | `http://localhost:3000` |
| Authorization callback URL | `http://localhost:3000/api/auth/callback/github` |

Copy the **Client ID** and generate a **Client secret**.

### 3. Configure environment

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
GITHUB_CLIENT_ID=your_github_client_id
GITHUB_CLIENT_SECRET=your_github_client_secret
AUTH_SECRET=<run: openssl rand -base64 32>
DATABASE_URL=file:./taskflow.db
```

### 4. Run migrations

```bash
npm run db:migrate
```

### 5. (Optional) Seed demo data

```bash
npm run db:seed
```

### 6. Start the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — you'll be redirected to `/login`.

---

## Project Structure

```
taskflow/
├── app/
│   ├── api/
│   │   ├── auth/
│   │   │   ├── [...nextauth]/route.ts   # NextAuth handler
│   │   │   └── upsert-user/route.ts     # User persistence (Node runtime)
│   │   └── trpc/[trpc]/route.ts         # tRPC fetch handler
│   ├── login/                           # GitHub sign-in page
│   ├── layout.tsx                       # Root layout + providers
│   ├── page.tsx                         # Protected dashboard
│   └── not-found.tsx                    # 404 page
│
├── components/
│   ├── tasks/
│   │   ├── task-card.tsx    # Individual task with priority bar + actions
│   │   ├── task-form.tsx    # Create / edit dialog
│   │   └── task-list.tsx    # List with stats, filters, search, skeletons
│   ├── ui/                  # Radix-based component primitives
│   │   ├── button.tsx
│   │   ├── dialog.tsx
│   │   ├── select.tsx
│   │   ├── skeleton.tsx
│   │   └── ...
│   ├── navbar.tsx           # Sticky header with theme toggle + user menu
│   └── providers/           # TRPCProvider, ThemeProvider
│
├── db/
│   ├── schema.ts    # Drizzle table definitions (users + tasks)
│   ├── index.ts     # LibSQL client + Drizzle instance
│   ├── migrate.ts   # SQL migration runner
│   └── seed.ts      # Demo data seeder
│
├── server/
│   ├── trpc.ts              # Init tRPC, context, protected procedure
│   ├── root.ts              # App router (combines all sub-routers)
│   └── routers/
│       └── tasks.ts         # list · create · update · delete · getById
│
├── lib/
│   ├── auth.ts    # NextAuth config (GitHub provider + JWT callbacks)
│   ├── trpc.ts    # createTRPCReact client
│   └── utils.ts   # cn() class helper
│
├── middleware.ts    # Edge route protection (no DB import)
├── __tests__/
│   ├── setup.ts         # In-memory LibSQL test DB
│   └── tasks.test.ts    # CRUD, filtering, Zod validation (12 tests)
│
├── .env.example
├── vercel.json
└── vitest.config.ts
```

---

## Scripts

```bash
npm run dev          # Start development server (Turbopack)
npm run build        # Production build
npm run start        # Start production server
npm run lint         # ESLint
npm run test         # Run test suite (Vitest)
npm run test:watch   # Watch mode
npm run db:migrate   # Run SQL migrations
npm run db:seed      # Seed demo tasks
```

---

## Database Schema

```sql
users (
  id          TEXT PRIMARY KEY,
  name        TEXT,
  email       TEXT UNIQUE,
  image       TEXT,
  created_at  TEXT DEFAULT (datetime('now'))
)

tasks (
  id           TEXT PRIMARY KEY,
  title        TEXT NOT NULL,
  description  TEXT,
  status       TEXT DEFAULT 'todo'    -- todo | in_progress | done
  priority     TEXT DEFAULT 'medium'  -- low | medium | high
  due_date     TEXT,
  user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
  created_at   TEXT DEFAULT (datetime('now')),
  updated_at   TEXT DEFAULT (datetime('now'))
)
```

---

## Deploying to Vercel

### 1. Database — set up Turso

```bash
npm install -g turso
turso auth login
turso db create taskflow
turso db show taskflow       # copy the URL
turso db tokens create taskflow  # copy the token
```

Run migrations against Turso:
```bash
DATABASE_URL=libsql://your-db.turso.io \
DATABASE_AUTH_TOKEN=your_token \
npx tsx db/migrate.ts
```

### 2. Deploy

```bash
npm install -g vercel
vercel
```

### 3. Set environment variables in Vercel dashboard

```
GITHUB_CLIENT_ID          = ...
GITHUB_CLIENT_SECRET      = ...
AUTH_SECRET               = ...
DATABASE_URL              = libsql://your-db.turso.io
DATABASE_AUTH_TOKEN       = ...
NEXTAUTH_URL              = https://your-app.vercel.app
```

Update your GitHub OAuth app callback URL to `https://your-app.vercel.app/api/auth/callback/github`.

---

## Architecture Decisions

**Why LibSQL instead of better-sqlite3?**
LibSQL doesn't require native compilation (no `node-gyp`), works the same locally and against Turso in production, and supports the same SQL dialect.

**Why is the DB not imported in middleware?**
Next.js middleware runs in the Edge runtime, which can't execute Node.js native modules. The auth middleware only validates the JWT (no DB call needed). User persistence is handled by `/api/auth/upsert-user`, which runs in the standard Node.js runtime.

**Why Zod for validation instead of DB CHECK constraints?**
LibSQL in-memory mode (used in tests) doesn't enforce SQLite CHECK constraints. Zod validation in tRPC procedures catches invalid values before they reach the DB, giving consistent behaviour across local, test, and production environments.

---

## License

MIT
