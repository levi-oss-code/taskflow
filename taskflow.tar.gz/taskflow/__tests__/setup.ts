import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "@/db/schema";
import { vi } from "vitest";

// Create an in-memory libsql DB for tests
export const testClient = createClient({ url: ":memory:" });
export const testDb = drizzle(testClient, { schema });

// Run migrations before all tests
export async function setupTestDb() {
  await testClient.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT,
      email TEXT UNIQUE,
      image TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);
  await testClient.execute(`
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      status TEXT NOT NULL DEFAULT 'todo',
      priority TEXT NOT NULL DEFAULT 'medium',
      due_date TEXT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);
}

export async function teardownTestDb() {
  await testClient.execute("DELETE FROM tasks");
  await testClient.execute("DELETE FROM users");
}

// Seed a test user
export const TEST_USER = {
  id: "user_test_001",
  name: "Test User",
  email: "test@example.com",
  image: null,
};

export async function createTestUser() {
  await testDb.insert(schema.users).values(TEST_USER).onConflictDoNothing();
}
