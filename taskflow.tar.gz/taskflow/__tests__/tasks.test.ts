import { describe, it, expect, beforeAll, afterEach } from "vitest";
import { testDb, setupTestDb, teardownTestDb, createTestUser, TEST_USER } from "./setup";
import { tasks, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";

beforeAll(async () => {
  await setupTestDb();
  await createTestUser();
});

afterEach(async () => {
  await testDb.delete(tasks);
});

const makeTask = (overrides = {}) => ({
  id: `task_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
  title: "Test Task",
  description: "A test description",
  status: "todo" as const,
  priority: "medium" as const,
  dueDate: null,
  userId: TEST_USER.id,
  ...overrides,
});

describe("Task CRUD", () => {
  it("creates a task", async () => {
    const task = makeTask({ title: "My first task" });
    await testDb.insert(tasks).values(task);
    const [found] = await testDb.select().from(tasks).where(eq(tasks.id, task.id));
    expect(found.title).toBe("My first task");
    expect(found.status).toBe("todo");
    expect(found.priority).toBe("medium");
  });

  it("lists tasks for a user", async () => {
    const t1 = makeTask({ title: "Task A", priority: "high" });
    const t2 = makeTask({ title: "Task B", priority: "low" });
    await testDb.insert(tasks).values([t1, t2]);
    const found = await testDb.select().from(tasks).where(eq(tasks.userId, TEST_USER.id));
    expect(found).toHaveLength(2);
  });

  it("updates a task status", async () => {
    const task = makeTask({ status: "todo" });
    await testDb.insert(tasks).values(task);
    await testDb.update(tasks).set({ status: "done" }).where(eq(tasks.id, task.id));
    const [updated] = await testDb.select().from(tasks).where(eq(tasks.id, task.id));
    expect(updated.status).toBe("done");
  });

  it("deletes a task", async () => {
    const task = makeTask();
    await testDb.insert(tasks).values(task);
    await testDb.delete(tasks).where(eq(tasks.id, task.id));
    const found = await testDb.select().from(tasks).where(eq(tasks.id, task.id));
    expect(found).toHaveLength(0);
  });

  it("does not return tasks from other users", async () => {
    await testDb.insert(users).values({ id: "other_user", name: "Other", email: "other@test.com" }).onConflictDoNothing();
    const myTask = makeTask({ title: "Mine" });
    const theirTask = makeTask({ id: `task_other_${Date.now()}`, title: "Theirs", userId: "other_user" });
    await testDb.insert(tasks).values([myTask, theirTask]);
    const myTasks = await testDb.select().from(tasks).where(eq(tasks.userId, TEST_USER.id));
    expect(myTasks).toHaveLength(1);
    expect(myTasks[0].title).toBe("Mine");
  });
});

describe("Task filtering", () => {
  it("filters by priority", async () => {
    await testDb.insert(tasks).values([
      makeTask({ title: "High priority", priority: "high" }),
      makeTask({ title: "Low priority", priority: "low" }),
      makeTask({ title: "Medium priority", priority: "medium" }),
    ]);
    const highTasks = await testDb
      .select()
      .from(tasks)
      .where(and(eq(tasks.userId, TEST_USER.id), eq(tasks.priority, "high")));
    expect(highTasks).toHaveLength(1);
    expect(highTasks[0].title).toBe("High priority");
  });

  it("filters by status", async () => {
    await testDb.insert(tasks).values([
      makeTask({ title: "Todo", status: "todo" }),
      makeTask({ title: "In Progress", status: "in_progress" }),
      makeTask({ title: "Done", status: "done" }),
    ]);
    const doneTasks = await testDb
      .select()
      .from(tasks)
      .where(and(eq(tasks.userId, TEST_USER.id), eq(tasks.status, "done")));
    expect(doneTasks).toHaveLength(1);
    expect(doneTasks[0].title).toBe("Done");
  });
});


import { z } from "zod";

// Zod schemas mirror tRPC router input validation
const taskStatusSchema = z.enum(["todo", "in_progress", "done"]);
const taskPrioritySchema = z.enum(["low", "medium", "high"]);
const taskCreateSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().max(2000).optional(),
  status: taskStatusSchema.default("todo"),
  priority: taskPrioritySchema.default("medium"),
  dueDate: z.string().optional(),
});

describe("Zod validation (mirrors tRPC input)", () => {
  it("rejects invalid status", () => {
    const result = taskStatusSchema.safeParse("invalid");
    expect(result.success).toBe(false);
    if (!result.success) {
      // Zod v4 uses "invalid_value", older versions use "invalid_enum_value"
      expect(["invalid_value", "invalid_enum_value"]).toContain(result.error.issues[0].code);
    }
  });

  it("rejects invalid priority", () => {
    const result = taskPrioritySchema.safeParse("critical");
    expect(result.success).toBe(false);
  });

  it("rejects empty title", () => {
    const result = taskCreateSchema.safeParse({ title: "" });
    expect(result.success).toBe(false);
  });

  it("accepts valid task payload", () => {
    const result = taskCreateSchema.safeParse({
      title: "Valid task",
      status: "in_progress",
      priority: "high",
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.status).toBe("in_progress");
      expect(result.data.priority).toBe("high");
    }
  });

  it("applies default values", () => {
    const result = taskCreateSchema.safeParse({ title: "Minimal task" });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.status).toBe("todo");
      expect(result.data.priority).toBe("medium");
    }
  });
});
