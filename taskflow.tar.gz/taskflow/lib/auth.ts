import NextAuth from "next-auth";
import GitHub from "next-auth/providers/github";

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    GitHub({
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    }),
  ],
  callbacks: {
    async signIn({ user }) {
      // We persist the user in the JWT; DB upsert happens via a separate API route
      if (!user.email) return false;
      return true;
    },
    async session({ session, token }) {
      if (token.dbId) {
        session.user.id = token.dbId as string;
      } else if (token.sub) {
        session.user.id = token.sub;
      }
      return session;
    },
    async jwt({ token, user, trigger }) {
      // On initial sign-in, upsert user in DB and store their DB id
      if (user && user.email) {
        try {
          const res = await fetch(
            `${process.env.NEXTAUTH_URL ?? "http://localhost:3000"}/api/auth/upsert-user`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ email: user.email, name: user.name, image: user.image }),
            }
          );
          if (res.ok) {
            const data = await res.json();
            token.dbId = data.id;
          }
        } catch {
          // Non-fatal — user can still authenticate; DB write will retry next sign-in
        }
      }
      return token;
    },
  },
  pages: { signIn: "/login" },
  session: { strategy: "jwt" },
});
