import { z } from "zod";
import { createTRPCRouter, protectedProcedure } from "../trpc";
import { tasks } from "@/db/schema";
import { eq, and, like, or } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

const taskCreateSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().max(2000).optional(),
  status: z.enum(["todo", "in_progress", "done"]).default("todo"),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueDate: z.string().optional(),
});

const taskUpdateSchema = taskCreateSchema.partial().extend({
  id: z.string(),
});

export const tasksRouter = createTRPCRouter({
  list: protectedProcedure
    .input(
      z.object({
        status: z.enum(["todo", "in_progress", "done", "all"]).default("all"),
        priority: z.enum(["low", "medium", "high", "all"]).default("all"),
        search: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const userId = ctx.session.user.id!;
      let allTasks = await ctx.db
        .select()
        .from(tasks)
        .where(eq(tasks.userId, userId))
        .all();

      if (input.status !== "all") {
        allTasks = allTasks.filter((t) => t.status === input.status);
      }
      if (input.priority !== "all") {
        allTasks = allTasks.filter((t) => t.priority === input.priority);
      }
      if (input.search) {
        const q = input.search.toLowerCase();
        allTasks = allTasks.filter((t) =>
          t.title.toLowerCase().includes(q)
        );
      }

      return allTasks.sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        return (
          priorityOrder[a.priority as keyof typeof priorityOrder] -
          priorityOrder[b.priority as keyof typeof priorityOrder]
        );
      });
    }),

  create: protectedProcedure
    .input(taskCreateSchema)
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.session.user.id!;
      const id = `task_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const now = new Date().toISOString();
      await ctx.db.insert(tasks).values({
        id,
        ...input,
        userId,
        createdAt: now,
        updatedAt: now,
      });
      return { id };
    }),

  update: protectedProcedure
    .input(taskUpdateSchema)
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.session.user.id!;
      const { id, ...data } = input;

      const existing = await ctx.db
        .select()
        .from(tasks)
        .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
        .get();

      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });

      await ctx.db
        .update(tasks)
        .set({ ...data, updatedAt: new Date().toISOString() })
        .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));

      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.session.user.id!;
      const existing = await ctx.db
        .select()
        .from(tasks)
        .where(and(eq(tasks.id, input.id), eq(tasks.userId, userId)))
        .get();

      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });

      await ctx.db
        .delete(tasks)
        .where(and(eq(tasks.id, input.id), eq(tasks.userId, userId)));

      return { success: true };
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const userId = ctx.session.user.id!;
      const task = await ctx.db
        .select()
        .from(tasks)
        .where(and(eq(tasks.id, input.id), eq(tasks.userId, userId)))
        .get();

      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      return task;
    }),
});
